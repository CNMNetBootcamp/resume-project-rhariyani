﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Resume.Models;

namespace Resume.Data
{
    public class DbInitializer
    {
        public static void Initialize(ResumeContext context)
        {
            context.Database.EnsureCreated();

            if (context.Applicant.Any())
            {
                return;   // DB has been seeded

            }

            var applicants = new Applicant[]
        {
                new Applicant { FirstName = "Rishita",   LastName = "Hariyani",
                    DateOfBirth = DateTime.Parse("1987-10-23") ,
                    Address ="1722 Vista del Norte Rd NM ",
                    Contact ="5053132020",
                    Email=" rishita.hariyani@gmail.com" ,
                    }

                 };

            foreach (Applicant s in applicants)
            {
                context.Applicant.Add(s);
            }
            context.SaveChanges();



            var educations = new Education[]
        {
                new Education { InstituteUniversity="XICA",
                    Title ="Computer Application",
                    Degree ="Bachelor's",
                    FromYear=DateTime.Parse("2005-03-11"),
                    ToYear = DateTime.Parse("2009-03-11"),
                    City="Ahmnedabad",
                    Country="India",
                  },

        };

            foreach (Education i in educations)
            {
                context.Education.Add(i);
            }
            context.SaveChanges();
         

            var references = new Reference[]
            {
                new Reference { FirstName = "Rimple",   LastName = "Chisrtian",
                Position="VB Coder" ,
                CompanyName="ABC",
                Address ="Paldi India ",
                Contact ="9898334682",
                Email=" rimple.Chris@yahoo.com",
                },

                new Reference { FirstName = "Jasmin",   LastName = "Panchal",
                Position="VB Coder" ,
                CompanyName="Prathama",
                Address ="Gurukul Ahmedabad India ",
                Contact ="9898225566",
                Email=" Jass.p@yahoo.com",},

            };

            foreach (Reference d in references)
            {
                context.Reference.Add(d);
            }
            context.SaveChanges();

            var jobs = new Job[]
            {
                new Job {
                Company="VFS",
                Position="Office",
                Duties="visa application process",
                FromYear=DateTime.Parse("2014-03-11"),
                ToYear = DateTime.Parse("2015-03-11"),
                Address ="Ashram Road Ahmedabad India ",
                Contact ="3800923",


                },

                new Job {
                Company="Stkabir",
                Position="Teacher",
                Duties="Computer teaching 1-9 grade",
                FromYear=DateTime.Parse("2010-03-11"),
                ToYear = DateTime.Parse("2013-03-11"),
                Address ="Navrangpura Ahmedabad India ",
                Contact ="9898225566",
                },

        };
            foreach (Job j in jobs)
            {
                context.Job.Add(j);
            }
            context.SaveChanges();

            var works = new Workexperience[]
                {
                new Workexperience
                {
                    ExperieceDescription = "airlines"
                },
                 new Workexperience
                {
                    ExperieceDescription = "School"
                }
                };

            foreach (Workexperience w in works)
            {
                context.Workexperience.Add(w);
            }
            context.SaveChanges();



            var skills = new Skill[]
            {
                new Skill {SkillName="Microsoftsuit"},
                new Skill {SkillName="SQl" },
               new Skill  {SkillName="DB" }

            };

            foreach (Skill c in skills)
            {
                context.Skill.Add(c);
            }
            context.SaveChanges();

           
        }

    }
}